// 生成文件（dm/gfx/tools/dmsh_chain.py --header，游戏 0100A6301214E000）：本源码树期望的 B 着色器库翻译链版本（缺省选项）；宿主只加载 <库目录>/b-<V>/
#define DMSH_CHAIN "a295a8035b7b"
